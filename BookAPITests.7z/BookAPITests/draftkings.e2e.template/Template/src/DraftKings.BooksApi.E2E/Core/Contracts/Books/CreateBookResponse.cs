﻿namespace DraftKings.BooksApi.E2E.Core.Contracts.Books
{
    public class CreateBookResponse
    {
        public int BookId { get; set; }
        public string OperationMessage { get; set; }
    }
}
