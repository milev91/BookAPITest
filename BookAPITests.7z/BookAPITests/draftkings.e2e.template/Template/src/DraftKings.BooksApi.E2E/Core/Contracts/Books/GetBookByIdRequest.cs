﻿namespace DraftKings.BooksApi.E2E.Core.Contracts.Books
{
    public class GetBookByIdRequest
    {
        public int BookId { get; set; }
    }
}
