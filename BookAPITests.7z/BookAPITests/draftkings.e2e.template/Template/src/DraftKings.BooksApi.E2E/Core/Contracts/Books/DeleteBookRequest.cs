﻿namespace DraftKings.BooksApi.E2E.Core.Contracts.Books
{
    public class DeleteBookRequest
    {
        public int BookId { get; set; }
    }
}
