﻿namespace DraftKings.BooksApi.E2E.Core.Contracts.Authorization
{
    public class LoginUserRequest
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
