﻿namespace DraftKings.BooksApi.E2E.Core.Config
{
    public class BaseConfig
    {
        public string BooksApiBaseUrl { get; set; }
    }
}