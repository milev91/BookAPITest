# Specflow E2E Template project
Template is based on the dotnet new subcommand.

## Usage
This will create a new project with the default project structure and Dockerfile
- clone this repo
- install the template

```
dotnet new -i <AbsolutePathToTheRepo\Template> (example: "dotnet new -i C:\Work\Repos\E2E\draftkings.e2e.template\Template")

```
- create a new folder for your project
- go to the projects directory
- create new E2E solution

```
dotnet new e2e -name <ProjectName> -unit <TeamName>
```

## To uninstall the template
```
dotnet new -u <AbsolutePathToTheRepo\Template>
```

## Cleanup
```
dotnet new --debug:reinit
```
